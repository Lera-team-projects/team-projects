package com.example.uservalidation;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserValidationApplication 
{
    public static void main(String[] args) 
    {
        SpringApplication.run(UserValidationApplication.class, args);
    }
}