package com.example.uservalidation.service;
import com.example.uservalidation.entity.User;

public interface UserService 
{
    User createUser(User user);
}