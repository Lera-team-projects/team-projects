package com.example.uservalidation.controller;

import com.example.uservalidation.entity.User;
import com.example.uservalidation.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController 
{

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<?> createUser(@Valid @RequestBody User user) 
    {
        return new ResponseEntity<>(userService.createUser(user), HttpStatus.CREATED);
    }
}