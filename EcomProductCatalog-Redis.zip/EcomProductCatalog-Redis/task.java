package com.search.service;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.springframework.stereotype.Service;

import com.search.entity.Product;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final SolrClient solrClient;

    public ProductService(SolrClient solrClient) {
        this.solrClient = solrClient;
    }

    public List<Product> searchProducts(String keyword) throws Exception {
        SolrQuery query = new SolrQuery();
        query.setQuery("name:*" + keyword + "* OR description:*" + keyword + "*");

        QueryResponse response = solrClient.query(query);

        return response.getResults().stream().map(doc -> mapDocToProduct(doc)).collect(Collectors.toList());
    }

    private Product mapDocToProduct(SolrDocument doc) {
        Product p = new Product();
        p.setId((String) doc.getFieldValue("id"));
        p.setName((String) doc.getFieldValue("name"));
        p.setDescription((String) doc.getFieldValue("description"));
        p.setCategory((String) doc.getFieldValue("category"));
        return p;
    }
}
