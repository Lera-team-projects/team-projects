package com.example.demo.scheduler;

import java.util.Set;
//import java.util.concurrent.TimeUnit;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.demo.service.ReservationService;

@Component
public class ReservationCleanUpScheduler {

    private final StringRedisTemplate redisTemplate;
    private final ReservationService reservationService;

    public ReservationCleanUpScheduler(StringRedisTemplate redisTemplate, ReservationService reservationService) {
        this.redisTemplate = redisTemplate;
        this.reservationService = reservationService;
    }

    @Scheduled(fixedRate = 5000) // runs every 5 seconds (adjust as needed)
    public void cleanupExpiredReservations() {
        Set<String> keys = redisTemplate.keys("reservation:*"); // inside method
        if (keys != null) {
            for (String key : keys) {
                String value = redisTemplate.opsForValue().get(key);
                if (value != null) {
                    String[] parts = value.split(":");
                    int quantity = Integer.parseInt(parts[0]);
                    long expiryTime = Long.parseLong(parts[1]);

                    if (System.currentTimeMillis() > expiryTime) {
                        String[] keyParts = key.split(":");
                        Long productId = Long.parseLong(keyParts[1]);
                        String cartId = keyParts[2];

                        reservationService.releaseReservation(productId, cartId, quantity);
                        redisTemplate.delete(key);
                    }
                }
            }
        }
    }
}