package com.example.demo.service;

public interface ReservationService {
void reserveProduct(Long productId,String cartid,int quantity);
void releaseReservation(Long productId, String cartId, int quantity);

}
