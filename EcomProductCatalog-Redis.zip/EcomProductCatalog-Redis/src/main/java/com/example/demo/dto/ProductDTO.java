package com.example.demo.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;



public class ProductDTO {
	@NotBlank(message="proudct name cannot be empty")
	@Size(min=3,message="product name must have atleast 3 characters")
private String name;
	@Size(max=500,message="description must be within 500 characters")
private String description;
	@NotNull(message="price is required")
	@Min(value=0,message="price must be positive")
private double price;
	@Min(value=0,message="stock quantity cannot be negative")
private int stockQuantity;
	
	public ProductDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductDTO(
			@NotBlank(message = "proudct name cannot be empty") @Size(min = 3, message = "product name must have atleast 3 characters") String name,
			@Size(max = 500, message = "description must be within 500 characters") String description,
			@NotNull(message = "price is required") @Min(value = 0, message = "price must be positive") double price,
			@Min(value = 0, message = "stock quantity cannot be negative") int stockQuantity) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
		this.stockQuantity = stockQuantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	@Override
	public String toString() {
		return "ProductDTO [name=" + name + ", description=" + description + ", price=" + price + ", stockQuantity="
				+ stockQuantity + "]";
	}
	
	
	
}
