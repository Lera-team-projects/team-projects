package com.example.demo.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
@ExceptionHandler(ProdNotFoundException.class)
public ResponseEntity<String> handleProdNotFound(ProdNotFoundException e){
	return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler (MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>> handleValidationErrors(MethodArgumentNotValidException e){
	Map<String,String> errors=new HashMap<>();
	e.getBindingResult().getFieldErrors()
	.forEach(error -> errors.put(error.getField(),error.getDefaultMessage()));
	return new ResponseEntity<>(errors,HttpStatus.BAD_REQUEST);

}
@ExceptionHandler(DupliacteProdNameException.class)
public ResponseEntity<String> handleDuplicateName(DupliacteProdNameException e) {
    return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
}
@ExceptionHandler(ProductOutOfStockException.class)
public ResponseEntity<Map<String, Object>> handleOutOfStock(ProductOutOfStockException ex) {
    Map<String, Object> errorResponse = new HashMap<>();
    errorResponse.put("message", ex.getMessage());
    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);

}
}
