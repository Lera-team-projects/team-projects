package com.example.demo.dto;

public class PromoCodeDTO {
private String promoCode;

public String getPromoCode() {
	return promoCode;
}

public void setPromoCode(String promoCode) {
	this.promoCode = promoCode;
}


}
