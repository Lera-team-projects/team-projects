package com.example.demo.exception;

public class InvalidPromoCodeException extends RuntimeException{

	public InvalidPromoCodeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
