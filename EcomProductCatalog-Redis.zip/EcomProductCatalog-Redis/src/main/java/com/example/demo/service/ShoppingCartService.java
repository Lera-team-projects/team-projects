package com.example.demo.service;

import com.example.demo.entity.ShoppingCart;

public interface ShoppingCartService {
ShoppingCart removeItem(String cartId,Long productId,int quantity);
ShoppingCart getCart(String cartId);
ShoppingCart applyPromotion(String cartId,String promoCode);
ShoppingCart addItem(String cartId, Long productId, int quantity);

}
