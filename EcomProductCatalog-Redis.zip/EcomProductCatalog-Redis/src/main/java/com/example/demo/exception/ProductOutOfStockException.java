package com.example.demo.exception;

public class ProductOutOfStockException extends RuntimeException {

	public ProductOutOfStockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
  
}
