package com.example.demo.exception;

public class ProdNotFoundException extends RuntimeException {


	public ProdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	


}