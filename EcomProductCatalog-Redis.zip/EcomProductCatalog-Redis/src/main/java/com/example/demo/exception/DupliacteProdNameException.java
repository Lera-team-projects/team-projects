package com.example.demo.exception;

public class DupliacteProdNameException extends RuntimeException{

	public DupliacteProdNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
