package com.example.demo.entity;

import java.util.HashMap;
import java.util.Map;

public class ShoppingCart {
private Map<Long,Integer> items = new HashMap<>();
private double subtotal;
private double discount;
private double total;

public Map<Long,Integer> getItems(){
	return items;
}

public double getSubtotal() {
	return subtotal;
}

public void setSubtotal(double subtotal) {
	this.subtotal = subtotal;
}

public double getDiscount() {
	return discount;
}

public void setDiscount(double discount) {
	this.discount = discount;
}

public double getTotal() {
	return total;
}

public void setTotal(double total) {
	this.total = total;
}

}
