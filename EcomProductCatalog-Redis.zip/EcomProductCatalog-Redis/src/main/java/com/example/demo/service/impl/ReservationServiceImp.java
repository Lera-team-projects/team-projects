package com.example.demo.service.impl;

import java.util.concurrent.TimeUnit;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Product;
import com.example.demo.exception.ProdNotFoundException;
import com.example.demo.exception.ProductOutOfStockException;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;
import com.example.demo.service.ReservationService;

@Service
public class ReservationServiceImp implements ReservationService {

    private static final Logger logger = LoggerFactory.getLogger(ReservationServiceImp.class);

    private final ProductService prodService;
    private final ProductRepository productRepo;
    private final RedissonClient redissonClient;
    private final StringRedisTemplate redisTemplate;

    public ReservationServiceImp(ProductService prodService, ProductRepository productRepo,
                                 RedissonClient redissonClient, StringRedisTemplate redisTemplate) {
        this.prodService = prodService;
        this.productRepo = productRepo;
        this.redissonClient = redissonClient;
        this.redisTemplate = redisTemplate;
    }

    @Override
    @Transactional
    public void reserveProduct(Long productId, String cartId, int quantity) {
        logger.info("Reserving productId={} for cartId={} with quantity={}", productId, cartId, quantity);
        RLock lock = redissonClient.getLock("lock:product:" + productId);
        try {
            if (lock.tryLock(10, 20, TimeUnit.SECONDS)) {
                logger.debug("Lock acquired for productId={}", productId);
                Product product = productRepo.findById(productId)
                        .orElseThrow(() -> {
                            logger.error("Product not found with ID={}", productId);
                            return new ProdNotFoundException("Product not found");
                        });

                if (product.getStockQuantity() < quantity) {
                    logger.warn("Not enough stock for productId={} requested={}, available={}",
                            productId, quantity, product.getStockQuantity());
                    throw new ProductOutOfStockException("Not enough stock for product: " + product.getName());
                }

                product.setStockQuantity(product.getStockQuantity() - quantity);
                productRepo.save(product);
                logger.debug("Stock decremented for productId={}, newQuantity={}", productId, product.getStockQuantity());

                long expiryTime = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(10);
                redisTemplate.opsForValue().set(
                        "reservation:" + productId + ":" + cartId,
                        quantity + ":" + expiryTime
                );
                logger.debug("Reservation stored in Redis for productId={}, cartId={}", productId, cartId);

                prodService.evictStockCache(productId);
                logger.info("Cache evicted for productId={}", productId);
            } else {
                logger.warn("Failed to acquire lock for productId={} during reserve", productId);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Thread interrupted while reserving productId={}", productId, e);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
                logger.debug("Lock released for productId={}", productId);
            }
        }
    }

    @Override
    public void releaseReservation(Long productId, String cartId, int quantity) {
        logger.info("Releasing reservation for productId={} from cartId={} with quantity={}", productId, cartId, quantity);
        RLock lock = redissonClient.getLock("lock:product:" + productId);
        try {
            if (lock.tryLock(10, 20, TimeUnit.SECONDS)) {
                logger.debug("Lock acquired for productId={} during release", productId);
                Product product = productRepo.findById(productId)
                        .orElseThrow(() -> {
                            logger.error("Product not found with ID={}", productId);
                            return new ProdNotFoundException("Product not found");
                        });

                product.setStockQuantity(product.getStockQuantity() + quantity);
                productRepo.save(product);
                logger.debug("Stock incremented for productId={}, newQuantity={}", productId, product.getStockQuantity());

                String reservationKey = "reservation:" + productId + ":" + cartId;
                redisTemplate.delete(reservationKey);
                logger.debug("Reservation removed from Redis for productId={}, cartId={}", productId, cartId);

                prodService.evictStockCache(productId);
                logger.info("Cache evicted for productId={}", productId);
            } else {
                logger.warn("Failed to acquire lock for productId={} during release", productId);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Thread interrupted while releasing reservation for productId={}", productId, e);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
                logger.debug("Lock released for productId={}", productId);
            }
        }
    }
}
