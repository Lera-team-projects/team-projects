package com.example.demo.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.demo.exception.InvalidPromoCodeException;
import com.example.demo.service.PromotionService;

@Service
public class PromotionServiceImp implements PromotionService {

    private static final Logger logger = LoggerFactory.getLogger(PromotionServiceImp.class);

    @Override
    public double validateAndGetDiscount(String promoCode, double subtotal) {
        logger.info("Validating promoCode={} for subtotal={}", promoCode, subtotal);

        if ("10OFF".equalsIgnoreCase(promoCode)) {
            double discount = subtotal * 0.10;
            logger.debug("PromoCode={} applied, discount={}", promoCode, discount);
            return discount;
        }

        if ("20OFF".equalsIgnoreCase(promoCode)) {
            double discount = subtotal * 0.20;
            logger.debug("PromoCode={} applied, discount={}", promoCode, discount);
            return discount;
        }

        logger.error("Invalid promoCode={} attempted", promoCode);
        throw new InvalidPromoCodeException("Invalid promo code: " + promoCode);
    }
}
