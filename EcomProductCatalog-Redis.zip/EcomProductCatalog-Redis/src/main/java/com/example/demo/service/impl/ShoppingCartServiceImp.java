package com.example.demo.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.entity.ShoppingCart;
import com.example.demo.exception.ProdNotFoundException;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.PromotionService;
import com.example.demo.service.ReservationService;
import com.example.demo.service.ShoppingCartService;

@Service
public class ShoppingCartServiceImp implements ShoppingCartService {

    private static final Logger logger = LoggerFactory.getLogger(ShoppingCartServiceImp.class);

    private final ProductRepository productRepo;
    private final PromotionService promoService;
    private final ReservationService reservationService;

    private Map<String, ShoppingCart> carts = new HashMap<>();

    public ShoppingCartServiceImp(ProductRepository productRepo, PromotionService promoService,
                                  ReservationService reservationService) {
        this.productRepo = productRepo;
        this.promoService = promoService;
        this.reservationService = reservationService;
    }

    @Override
    public ShoppingCart addItem(String cartId, Long productId, int quantity) {
        logger.info("Adding productId={} (quantity={}) to cartId={}", productId, quantity, cartId);

        reservationService.reserveProduct(productId, cartId, quantity);

        ShoppingCart cart = carts.getOrDefault(cartId, new ShoppingCart());
        cart.getItems().merge(productId, quantity, Integer::sum);

        recalcCart(cart);
        carts.put(cartId, cart);

        logger.debug("Cart after addItem: {}", cart);
        return cart;
    }

    @Override
    public ShoppingCart removeItem(String cartId, Long productId, int quantity) {
        logger.info("Removing productId={} (quantity={}) from cartId={}", productId, quantity, cartId);

        ShoppingCart cart = carts.get(cartId);
        if (cart != null) {
            reservationService.releaseReservation(productId, cartId, quantity);
            cart.getItems().remove(productId);
            recalcCart(cart);
            logger.debug("Cart after removeItem: {}", cart);
        } else {
            logger.warn("No cart found with cartId={} while trying to remove item", cartId);
        }

        return cart;
    }

    @Override
    public ShoppingCart getCart(String cartId) {
        logger.info("Fetching cart with cartId={}", cartId);
        ShoppingCart cart = carts.getOrDefault(cartId, new ShoppingCart());
        logger.debug("Fetched cart details: {}", cart);
        return cart;
    }

    @Override
    public ShoppingCart applyPromotion(String cartId, String promoCode) {
        logger.info("Applying promoCode={} on cartId={}", promoCode, cartId);

        ShoppingCart cart = carts.get(cartId);
        if (cart == null) {
            logger.warn("No cart found with cartId={} when applying promo", cartId);
            return null;
        }

        if (cart.getSubtotal() <= 0) {
            logger.warn("Cart subtotal is 0 or less for cartId={}, skipping promo", cartId);
            cart.setDiscount(0);
            cart.setTotal(0);
            return cart;
        }

        double discount = promoService.validateAndGetDiscount(promoCode, cart.getSubtotal());
        cart.setDiscount(discount);
        cart.setTotal(cart.getSubtotal() - discount);

        logger.debug("Cart after applying promo: {}", cart);
        return cart;
    }

    private void recalcCart(ShoppingCart cart) {
        logger.info("Recalculating cart totals");

        double subtotal = cart.getItems().entrySet().stream()
                .mapToDouble(e -> {
                    Product p = productRepo.findById(e.getKey())
                            .orElseThrow(() -> {
                                logger.error("Product not found with ID={}", e.getKey());
                                return new ProdNotFoundException("Product not found with ID:" + e.getKey());
                            });
                    return p.getPrice() * e.getValue();
                })
                .sum();

        cart.setSubtotal(subtotal);
        cart.setTotal(subtotal - cart.getDiscount());

        logger.debug("Cart recalculated: subtotal={}, discount={}, total={}",
                cart.getSubtotal(), cart.getDiscount(), cart.getTotal());
    }
}
