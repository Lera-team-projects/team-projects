package com.example.demo.service;

public interface PromotionService {
double validateAndGetDiscount(String promoCode,double subtotal);
}
