package com.example.demo.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.example.demo.dto.ProductDTO;
import com.example.demo.entity.Product;
import com.example.demo.exception.DupliacteProdNameException;
import com.example.demo.exception.ProdNotFoundException;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;

@Service
public class ProductServiceImp implements ProductService {

    private static final Logger logger = LoggerFactory.getLogger(ProductServiceImp.class);

    @Autowired
    private ProductRepository productRepo;

    @Override
    public Product createProduct(ProductDTO prodDTO) {
        logger.info("Attempting to create product with name={}", prodDTO.getName());

        if (productRepo.existsByName(prodDTO.getName())) {
            logger.warn("Duplicate product creation attempt with name={}", prodDTO.getName());
            throw new DupliacteProdNameException("Product name already exists: " + prodDTO.getName());
        }

        Product product = new Product();
        product.setName(prodDTO.getName());
        product.setDescription(prodDTO.getDescription());
        product.setPrice(prodDTO.getPrice());
        product.setStockQuantity(prodDTO.getStockQuantity());

        Product created = productRepo.save(product);
        logger.debug("Product successfully created: {}", created);
        return created;
    }

    @Override
    @Cacheable(value = "productStock", key = "#id")
    public Product getProductById(Long id) {
        logger.info("Fetching product by id={}", id);
        return productRepo.findById(id)
                .orElseThrow(() -> {
                    logger.error("Product not found with id={}", id);
                    return new ProdNotFoundException("product not found with the given id " + id);
                });
    }

    @Override
    public List<Product> getAllProducts() {
        logger.info("Fetching all products");
        List<Product> products = productRepo.findAll();
        logger.debug("Total products fetched={}", products.size());
        return products;
    }

    @Override
    public Product updateProduct(Long id, ProductDTO prodDTO) {
        logger.info("Updating product with id={}", id);

        Product product = getProductById(id);
        product.setName(prodDTO.getName());
        product.setDescription(prodDTO.getDescription());
        product.setPrice(prodDTO.getPrice());
        product.setStockQuantity(prodDTO.getStockQuantity());

        Product updated = productRepo.save(product);
        evictStockCache(id);

        logger.debug("Product updated successfully: {}", updated);
        return updated;
    }

    @Override
    public void deleteProduct(Long id) {
        logger.info("Deleting product with id={}", id);

        Product product = getProductById(id);
        productRepo.delete(product);
        evictStockCache(id);

        logger.debug("Product deleted with id={}", id);
    }

    @Override
    @Cacheable(value = "productStock", key = "#productId")
    public Integer getStock(Long productId) {
        logger.info("Fetching stock for productId={}", productId);

        Integer stock = productRepo.findStockQuantityById(productId);
        if (stock == null) {
            logger.error("Stock not found for productId={}", productId);
            throw new ProdNotFoundException("product not found with the given id " + productId);
        }

        logger.debug("Stock for productId={} is {}", productId, stock);
        return stock;
    }

    @Override
    @CacheEvict(value = "productStock", key = "#productId")
    public void evictStockCache(Long productId) {
        logger.info("Evicting stock cache for productId={}", productId);
    }
}
