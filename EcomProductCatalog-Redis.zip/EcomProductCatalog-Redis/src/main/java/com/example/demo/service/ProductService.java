package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.ProductDTO;
import com.example.demo.entity.Product;

public interface ProductService {
Product createProduct(ProductDTO prodDTO);
Product getProductById(Long id);
List<Product> getAllProducts();
Product updateProduct(Long id,ProductDTO prodDTO);
void deleteProduct(Long id);
void evictStockCache(Long productId);
Integer getStock(Long productId);

}
