package com.example.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CartItemDTO;
import com.example.demo.dto.PromoCodeDTO;
import com.example.demo.entity.ShoppingCart;
import com.example.demo.service.ShoppingCartService;

@RestController
@RequestMapping("/carts")
public class ShoppingCartController {

    private static final Logger logger = LoggerFactory.getLogger(ShoppingCartController.class);

    private final ShoppingCartService cartService;

    public ShoppingCartController(ShoppingCartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/{cartId}/items")
    public ResponseEntity<ShoppingCart> addItem(@PathVariable String cartId, @RequestBody CartItemDTO item) {
        logger.info("Adding item to cartId={} with productId={} and quantity={}", cartId, item.getProductId(), item.getQuantity());
        ShoppingCart updatedCart = cartService.addItem(cartId, item.getProductId(), item.getQuantity());
        logger.debug("Cart after adding item: {}", updatedCart);
        return new ResponseEntity<>(updatedCart, HttpStatus.OK);
    }

    @DeleteMapping("/{cartId}/items/{productId}")
    public ResponseEntity<ShoppingCart> removeItem(@PathVariable String cartId, @PathVariable Long productId, @RequestParam int quantity) {
        logger.info("Removing productId={} (quantity={}) from cartId={}", productId, quantity, cartId);
        ShoppingCart updatedCart = cartService.removeItem(cartId, productId, quantity);
        logger.debug("Cart after removing item: {}", updatedCart);
        return new ResponseEntity<>(updatedCart, HttpStatus.OK);
    }

    @GetMapping("/{cartId}")
    public ResponseEntity<ShoppingCart> getCart(@PathVariable String cartId) {
        logger.info("Fetching cart with cartId={}", cartId);
        ShoppingCart cart = cartService.getCart(cartId);
        logger.debug("Fetched cart details: {}", cart);
        return new ResponseEntity<>(cart, HttpStatus.OK);
    }

    @PostMapping("/{cartId}/applyPromo")
    public ResponseEntity<ShoppingCart> applyPromo(@PathVariable String cartId, @RequestBody PromoCodeDTO promoCode) {
        logger.info("Applying promoCode={} to cartId={}", promoCode.getPromoCode(), cartId);
        ShoppingCart updatedCart = cartService.applyPromotion(cartId, promoCode.getPromoCode());
        logger.debug("Cart after applying promo: {}", updatedCart);
        return new ResponseEntity<>(updatedCart, HttpStatus.OK);
    }
}
