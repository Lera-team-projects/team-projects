/**
 * 
 */
/**
 * 
 */
module CustomerLoyaltySearch {
}