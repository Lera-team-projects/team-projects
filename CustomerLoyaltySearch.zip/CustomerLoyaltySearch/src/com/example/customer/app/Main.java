package com.example.customer.app;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.example.customer.model.Customer;
import com.example.customer.service.CustomerService;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerService service = new CustomerService();
		List<Customer> customers =Arrays.asList(
				new Customer(1,"Arun","SILVER"),
				new Customer(2,"Charan","GOLD"),
				new Customer (3,"Varun","BRONZE"),
				new Customer (4,"Karan","GOLD"));
		Optional<Customer> goldCust= service.findCust(customers);
		goldCust.ifPresentOrElse( 
				customer ->System.out.println("GOLD customer is " +customer.getName()),
				() -> System.out.println("No GOLD customer found")
				);

	}

}
