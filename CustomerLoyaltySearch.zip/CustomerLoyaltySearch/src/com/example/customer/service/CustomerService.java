package com.example.customer.service;

import java.util.List;
import java.util.Optional;

import com.example.customer.model.Customer;

public class CustomerService {

	public Optional<Customer> findCust(List<Customer> customers){
		return customers.stream()
				.filter(c ->"GOLD".equalsIgnoreCase(c.getLoyaltyLevel()))
				.findFirst();
	}
}
 