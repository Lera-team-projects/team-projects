package com.example.customer.model;

public class Customer {
 private int cusId;
 private String name;
 private String loyaltyLevel;
 
 public Customer(int cusId, String name, String loyaltyLevel) {
	super();
	this.cusId = cusId;
	this.name = name;
	this.loyaltyLevel = loyaltyLevel;
 }
 public int getCusId() {
	return cusId;
 }
 public void setCusId(int cusId) {
	this.cusId = cusId;
 }
 public String getName() {
	return name;
 }
 public void setName(String name) {
	this.name = name;
 }
 public String getLoyaltyLevel() {
	return loyaltyLevel;
 }
 public void setLoyaltyLevel(String loyaltyLevel) {
	this.loyaltyLevel = loyaltyLevel;
 }
 
 
}
