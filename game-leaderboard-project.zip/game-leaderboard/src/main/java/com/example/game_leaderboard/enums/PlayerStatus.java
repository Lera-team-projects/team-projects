package com.example.game_leaderboard.enums;

public enum PlayerStatus {
    IN_QUEUE,
    IN_MATCH,
    OFFLINE
}
