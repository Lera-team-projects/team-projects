package com.example.game_leaderboard.service;

import com.example.game_leaderboard.entity.Score;
import com.example.game_leaderboard.repository.ScoreRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScoreService {

    private final ScoreRepository scoreRepository;

    public ScoreService(ScoreRepository scoreRepository) {
        this.scoreRepository = scoreRepository;
    }

    public Score saveScore(Score score) {
        return scoreRepository.save(score);
    }

    public List<Score> getTopScores(Long gameId) {
        return scoreRepository.findTop10ByGameIdOrderByScoreDesc(gameId);
    }
}
