package com.example.game_leaderboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameLeaderboardApplication 
{

	public static void main(String[] args) 
	{
		
		SpringApplication.run(GameLeaderboardApplication.class, args);
		
	}
}
  