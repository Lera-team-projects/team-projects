package com.example.game_leaderboard.service;

import com.example.game_leaderboard.dto.MatchmakingRequest;
import com.example.game_leaderboard.entity.Match;
import com.example.game_leaderboard.entity.Player;
import com.example.game_leaderboard.repository.MatchRepository;
import com.example.game_leaderboard.repository.PlayerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

@Service
public class MatchMakingService {

    private final PlayerRepository playerRepository;
    private final MatchRepository matchRepository;

    public MatchMakingService(PlayerRepository playerRepository, MatchRepository matchRepository) {
        this.playerRepository = playerRepository;
        this.matchRepository = matchRepository;
    }

    @Transactional
    public Match createMatch(MatchmakingRequest request) {
        List<Player> availablePlayers = playerRepository.findByStatus("Available");

        if (availablePlayers.size() < request.getNumberOfPlayers()) {
            throw new RuntimeException("Not enough players to start a match");
        }

        Collections.shuffle(availablePlayers);
        List<Player> selectedPlayers = availablePlayers.subList(0, request.getNumberOfPlayers());

        // Update player statuses
        for (Player player : selectedPlayers) {
            player.setStatus("In-Match");
            playerRepository.save(player);
        }

        // Create and save the match
        Match match = new Match();
        match.setMatchName("Match-" + UUID.randomUUID());
        match.setPlayers(selectedPlayers); // NEW
        matchRepository.save(match);

        return match;
    }
}
