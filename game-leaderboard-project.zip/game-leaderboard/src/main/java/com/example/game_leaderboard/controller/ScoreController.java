package com.example.game_leaderboard.controller;

import com.example.game_leaderboard.entity.Score;
import com.example.game_leaderboard.service.ScoreService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ScoreController {

    private final ScoreService scoreService;

    public ScoreController(ScoreService scoreService) {
        this.scoreService = scoreService;
    }

    @PostMapping("/scores")
    public Score submitScore(@RequestBody Score score) {
        return scoreService.saveScore(score);
    }

    @GetMapping("/leaderboards/{gameId}")
    public List<Score> getLeaderboard(@PathVariable Long gameId) {
        return scoreService.getTopScores(gameId);
    }
}
