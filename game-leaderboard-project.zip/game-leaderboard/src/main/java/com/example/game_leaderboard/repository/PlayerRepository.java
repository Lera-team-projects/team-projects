package com.example.game_leaderboard.repository;

import com.example.game_leaderboard.entity.Player;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PlayerRepository extends JpaRepository<Player, Long> 
{

    List<Player> findByStatus(String status); 
}
