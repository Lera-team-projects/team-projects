package com.example.game_leaderboard.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "skill_ratings")
public class SkillRating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int eloScore;

    @OneToOne
    @JoinColumn(name = "player_id", nullable = false, unique = true)
    private Player player;

    // Constructors
    public SkillRating() {}

    public SkillRating(Player player, int eloScore) {
        this.player = player;
        this.eloScore = eloScore;
    }

    public Long getId() {
        return id;
    }

    public int getEloScore() {
        return eloScore;
    }

    public void setEloScore(int eloScore) {
        this.eloScore = eloScore;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }
}
