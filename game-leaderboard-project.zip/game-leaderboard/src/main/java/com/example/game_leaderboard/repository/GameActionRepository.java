package com.example.game_leaderboard.repository;

import com.example.game_leaderboard.entity.GameAction;
import com.example.game_leaderboard.entity.Match;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GameActionRepository extends JpaRepository<GameAction, Long> 
{
    List<GameAction> findByMatchOrderByTimestampAsc(Match match);
}
