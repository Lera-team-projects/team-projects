package com.example.game_leaderboard.controller;

import com.example.game_leaderboard.entity.GameAction;
import com.example.game_leaderboard.entity.Match;
import com.example.game_leaderboard.service.GameActionService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/game-actions")
public class GameActionController {

    private final GameActionService gameActionService;

    public GameActionController(GameActionService gameActionService) {
        this.gameActionService = gameActionService;
    }

    @GetMapping("/match/{matchId}")
    public List<GameAction> getActionsByMatch(@PathVariable Long matchId) {
        Match match = new Match();
        match.setId(matchId);
        return gameActionService.getActionsByMatch(match);
    }

    @PostMapping
    public GameAction saveAction(@RequestBody GameAction action) {
        return gameActionService.saveAction(action);
    }
}
