package com.example.game_leaderboard.dto;

import java.util.List;

public class MatchResponse {
    private Long matchId;
    private List<Long> playerIds;

    public MatchResponse(Long matchId, List<Long> playerIds) {
        this.matchId = matchId;
        this.playerIds = playerIds;
    }

   
    public Long getMatchId() {
        return matchId;
    }

    public void setMatchId(Long matchId) {
        this.matchId = matchId;
    }

    public List<Long> getPlayerIds() {
        return playerIds;
    }

    public void setPlayerIds(List<Long> playerIds) {
        this.playerIds = playerIds;
    }
}
