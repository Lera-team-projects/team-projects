package com.example.game_leaderboard.service;

import com.example.game_leaderboard.entity.GameAction;
import com.example.game_leaderboard.entity.Match;
import com.example.game_leaderboard.repository.GameActionRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class GameActionService {

    private final GameActionRepository gameActionRepository;

    public GameActionService(GameActionRepository gameActionRepository) {
        this.gameActionRepository = gameActionRepository;
    }

    public List<GameAction> getActionsByMatch(Match match) {
        return gameActionRepository.findByMatchOrderByTimestampAsc(match);
    }

    public GameAction saveAction(GameAction action) {
        return gameActionRepository.save(action);
    }
}
