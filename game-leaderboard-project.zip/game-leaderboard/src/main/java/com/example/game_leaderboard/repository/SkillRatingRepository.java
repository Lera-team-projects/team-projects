package com.example.game_leaderboard.repository;

import com.example.game_leaderboard.entity.SkillRating;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SkillRatingRepository extends JpaRepository<SkillRating, Long> 
{
    Optional<SkillRating> findByPlayer_Id(Long playerId); 
}

