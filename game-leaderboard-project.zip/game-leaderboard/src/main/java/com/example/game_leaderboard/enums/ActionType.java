package com.example.game_leaderboard.enums;

public enum ActionType {
    MOVE,
    ATTACK,
    DEFEND,
    USE_ABILITY
}
