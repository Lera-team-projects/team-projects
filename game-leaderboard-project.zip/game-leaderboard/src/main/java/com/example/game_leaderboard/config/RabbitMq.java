package com.example.game_leaderboard.config;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class RabbitMq 
{
	public static final String GAME_QUEUE = "game_queue";
	
	@Bean
	public Queue queue()
	{
		return new Queue (GAME_QUEUE, false);
	}
	@Bean
	public ConnectionFactory connectionFactory()
	{
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory("localhost");
		connectionFactory.setUsername("Guest");
		connectionFactory.setPassword("Guest");
		return connectionFactory;			
	}
	@Bean 
	public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) 
	 {
		return new RabbitTemplate (connectionFactory);
	}
}