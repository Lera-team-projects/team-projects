package com.example.game_leaderboard.controller;

import com.example.game_leaderboard.dto.MatchmakingRequest;
import com.example.game_leaderboard.entity.Match;
import com.example.game_leaderboard.service.MatchMakingService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/matchmaking")
public class MatchMakingController {

    private final MatchMakingService matchMakingService;

    public MatchMakingController(MatchMakingService matchMakingService) {
        this.matchMakingService = matchMakingService;
    }

    @PostMapping("/create")
    public Match createMatch(@RequestBody MatchmakingRequest request) {
        return matchMakingService.createMatch(request);
    }
}
