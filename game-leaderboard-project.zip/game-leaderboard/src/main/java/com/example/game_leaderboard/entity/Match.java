package com.example.game_leaderboard.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "matches")
public class Match {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String matchName;

    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<GameAction> actions;

    // ✅ New field to link players
    @ManyToMany
    @JoinTable(
            name = "match_players",
            joinColumns = @JoinColumn(name = "match_id"),
            inverseJoinColumns = @JoinColumn(name = "player_id")
    )
    private List<Player> players;

    public Match() {}

    public Match(String matchName) {
        this.matchName = matchName;
    }

    // --- Getters and Setters ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getMatchName() { return matchName; }
    public void setMatchName(String matchName) { this.matchName = matchName; }

    public List<GameAction> getActions() { return actions; }
    public void setActions(List<GameAction> actions) { this.actions = actions; }

    public List<Player> getPlayers() { return players; }
    public void setPlayers(List<Player> players) { this.players = players; }
}
