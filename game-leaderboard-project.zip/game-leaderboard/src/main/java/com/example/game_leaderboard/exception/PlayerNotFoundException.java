package com.example.game_leaderboard.exception;



public class PlayerNotFoundException extends RuntimeException
{

	private static final long serialVersionUID = 1L;
	
	public PlayerNotFoundException(Long playerid)
	{
		super("Player with "+ playerid+ " is not found");
	}
	
}