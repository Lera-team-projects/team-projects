package com.example.game_leaderboard.exception;



public class PlayerAlreadyInQueue extends RuntimeException
{

	private static final long serialVersionUID = 1L;
	
	public  PlayerAlreadyInQueue (Long playerid)
	{
		super ("the player "+playerid+" is already in matchmaking");
	}
	
}