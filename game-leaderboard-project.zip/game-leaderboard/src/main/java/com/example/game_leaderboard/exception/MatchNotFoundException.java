package com.example.game_leaderboard.exception;

public class MatchNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public MatchNotFoundException(Long playerId) {
        super("No match found for player with ID " + playerId);
    }

    public MatchNotFoundException(String message) {
        super(message);
    }
}
