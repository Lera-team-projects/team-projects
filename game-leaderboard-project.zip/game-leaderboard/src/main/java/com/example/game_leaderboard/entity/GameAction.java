package com.example.game_leaderboard.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class GameAction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String action;

    private LocalDateTime timestamp;

    @ManyToOne
    @JoinColumn(name = "match_id")
    private Match match;

  
    public GameAction() {}

    public GameAction(String action, LocalDateTime timestamp, Match match) {
        this.action = action;
        this.timestamp = timestamp;
        this.match = match;
    }

   
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public Match getMatch() { return match; }
    public void setMatch(Match match) { this.match = match; }
}
