package com.example.game_leaderboard.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class MatchmakingRequest {

    @NotNull(message = "Game ID cannot be null")
    private Long gameId;

    @Min(value = 2, message = "At least 2 players are required to start a match")
    private int numberOfPlayers;

    public MatchmakingRequest() {}

    public MatchmakingRequest(Long gameId, int numberOfPlayers) {
        this.gameId = gameId;
        this.numberOfPlayers = numberOfPlayers;
    }

    // --- Getters & Setters ---
    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public int getNumberOfPlayers() {
        return numberOfPlayers;
    }

    public void setNumberOfPlayers(int numberOfPlayers) {
        this.numberOfPlayers = numberOfPlayers;
    }
}
