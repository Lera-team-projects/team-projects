-- Preload Players
INSERT INTO players (player_name, status) VALUES ('Alice', 'Available');
INSERT INTO players (player_name, status) VALUES ('Bob', 'Available');
INSERT INTO players (player_name, status) VALUES ('Charlie', 'Available');
