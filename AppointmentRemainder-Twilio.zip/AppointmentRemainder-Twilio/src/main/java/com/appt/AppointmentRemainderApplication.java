package com.appt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication

@Configuration
@EnableScheduling
@EnableAsync
public class AppointmentRemainderApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppointmentRemainderApplication.class, args);
	}

}
