package com.appt.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name="appointments")
public class Appointment {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private Long id;
	@NotBlank(message="client name is required")
private String clientName;
	@Email(message="invalid email format")
	@NotBlank(message="email is mandatory to receive further updates")
private String clientEmail;
@Pattern(regexp="^\\+?[0-9]{10,15}$", message="please provide valid mobile number")
@NotBlank(message="phone number is mandatory to receive further updates")
private String clientPhone;
	@NotNull(message="please provide when you want an appointment")	
	@Future(message = "Appointment must be in the future")
private LocalDateTime appointmentDateTime;
private boolean reminderSent=false;
private String location="XYZ Clinic Hyd";
@NotBlank(message="this field is required to book an appointemt")
private String service;
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getClientName() {
	return clientName;
}
public void setClientName(String clientName) {
	this.clientName = clientName;
}
public String getClientEmail() {
	return clientEmail;
}
public void setClientEmail(String clientEmail) {
	this.clientEmail = clientEmail;
}
public String getClientPhone() {
	return clientPhone;
}
public void setClientPhone(String clientPhone) {
	this.clientPhone = clientPhone;
}
public LocalDateTime getAppointmentDateTime() {
	return appointmentDateTime;
}
public void setAppointmentDateTime(LocalDateTime appointmentDateTime) {
	this.appointmentDateTime = appointmentDateTime;
}
public boolean isReminderSent() {
	return reminderSent;
}
public void setReminderSent(boolean reminderSent) {
	this.reminderSent = reminderSent;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getService() {
	return service;
}
public void setService(String service) {
	this.service = service;
}


}