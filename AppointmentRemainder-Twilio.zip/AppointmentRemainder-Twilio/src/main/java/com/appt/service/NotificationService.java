package com.appt.service;

import jakarta.mail.MessagingException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.appt.entity.Appointment;
import com.appt.repository.AppointmentRepository;

@Service
public class NotificationService {

    private final EmailService emailService;
    private final WhatsappService whatsappService;
    private final AppointmentRepository repo;
    public NotificationService(EmailService emailService, WhatsappService whatsappService, AppointmentRepository repo) {
		super();
		this.emailService = emailService;
		this.whatsappService = whatsappService;
		this.repo = repo;
	}
	@Async
    public void processReminder(Appointment appt) {
        try {
            emailService.sendRemainder(appt);
        } catch (MessagingException e) {
            
            System.err.println("Email send error: " + e.getMessage());
        }

        try {
            whatsappService.sendReminder(appt);
        } catch (Exception e) {
            System.err.println("WhatsApp send error: " + e.getMessage());
        }
        appt.setReminderSent(true);
        repo.save(appt);

        System.out.println("Reminder sent & status updated to TRUE");
    }
}

