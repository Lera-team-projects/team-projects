package com.appt.service;

import com.appt.entity.Appointment;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;

@Service
public class PdfGenerationService {

    private static final Logger logger = LoggerFactory.getLogger(PdfGenerationService.class);

    public ByteArrayResource generateAppointmentSummary(Appointment appt) {
        try {
            logger.info("Starting PDF generation for appointment ID: {}", appt.getId());

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document doc = new Document(PageSize.A4, 36, 36, 36, 36);
            PdfWriter.getInstance(doc, baos);
            doc.open();

            Font h1 = new Font(Font.HELVETICA, 18, Font.BOLD);
            Font p  = new Font(Font.HELVETICA, 12);

            doc.add(new Paragraph("Appointment Summary", h1));
            doc.add(Chunk.NEWLINE);

            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            doc.add(new Paragraph("Client: " + appt.getClientName(), p));
            doc.add(new Paragraph("Email: " + appt.getClientEmail(), p));
            doc.add(new Paragraph("Phone: " + appt.getClientPhone(), p));
            doc.add(new Paragraph("Service: " + appt.getService(), p));
            doc.add(new Paragraph("Location: " + appt.getLocation(), p));
            doc.add(new Paragraph("Date & Time: " + appt.getAppointmentDateTime().format(fmt), p));

            doc.close();
            logger.info("PDF generation completed for appointment ID: {}", appt.getId());

            return new ByteArrayResource(baos.toByteArray());
        } catch (Exception e) {
            logger.error("PDF generation failed for appointment ID {}: {}", appt.getId(), e.getMessage(), e);
            throw new RuntimeException("PDF generation failed", e);
        }
    }
}
