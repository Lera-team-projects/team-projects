package com.appt.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import com.appt.entity.Appointment;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    PdfGenerationService pdfService;

    private final JavaMailSender mailSender;
    private final SpringTemplateEngine templateEngine;

    @Value("${mail.from}")
    private String from;

    public EmailService(JavaMailSender mailSender, SpringTemplateEngine templateEngine) {
        this.mailSender = mailSender;
        this.templateEngine = templateEngine;
    }

    public void sendRemainder(Appointment appt) throws MessagingException {
        logger.info("Preparing email reminder for appointment ID: {}", appt.getId());

        Context ctx = new Context();
        ctx.setVariable("name", appt.getClientName());
        ctx.setVariable("dateTime", appt.getAppointmentDateTime());
        ctx.setVariable("location", appt.getLocation());
        ctx.setVariable("service", appt.getService());

        String html = templateEngine.process("appointment-remainder.html", ctx);
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

        helper.setFrom(from);
        helper.setTo(appt.getClientEmail());
        helper.setSubject("Appointment Reminder - " + appt.getAppointmentDateTime());
        helper.setText(html, true);

        logger.info("Generating PDF attachment for appointment ID: {}", appt.getId());
        ByteArrayResource pdf = pdfService.generateAppointmentSummary(appt);
        helper.addAttachment("appointment-" + appt.getId() + ".pdf", pdf);

        mailSender.send(message);
        logger.info("Email reminder sent successfully for appointment ID: {}", appt.getId());
    }
}
