package com.appt.service;

import com.appt.entity.Appointment;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class WhatsappService {

    private static final Logger logger = LoggerFactory.getLogger(WhatsappService.class);

    @Value("${twilio.accountSid}")
    private String accountSid;

    @Value("${twilio.authToken}")
    private String authToken;    

    @Value("${twilio.whatsapp.from}")
    private String fromNumber;

    @PostConstruct
    public void init() {
        Twilio.init(accountSid, authToken);
        logger.info("Twilio initialized with Account SID: {}", accountSid);
    }

    public void sendReminder(Appointment appt) {
        try {
            logger.info("Preparing WhatsApp reminder for appointment ID: {}", appt.getId());

            String msg = String.format(
                    "Hi %s,\nThis is a reminder for your appointment.\nDate: %s\nLocation: %s\nService: %s\nPlease check your email for more details...THANK YOU",
                    appt.getClientName(),
                    appt.getAppointmentDateTime(),
                    appt.getLocation(),
                    appt.getService());

            Message message = Message.creator(
                    new PhoneNumber("whatsapp:" + appt.getClientPhone()),  
                    new PhoneNumber(fromNumber),msg).create();

            logger.info("WhatsApp reminder sent successfully for appointment ID: {}. SID: {}", appt.getId(), message.getSid());
        } catch (Exception e) {
            logger.error("Failed to send WhatsApp reminder for appointment ID {}: {}", appt.getId(), e.getMessage(), e);
        }
    }
}
