package com.appt.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.appt.entity.Appointment;
import com.appt.repository.AppointmentRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReminderScheduler {

    private static final Logger logger = LoggerFactory.getLogger(ReminderScheduler.class);

    private final AppointmentRepository repo;
    private final NotificationService notificationService;

    public ReminderScheduler(AppointmentRepository repo, NotificationService notificationService) {
        this.repo = repo;
        this.notificationService = notificationService;
    }

    @Scheduled(cron = "0 0 * * * ?")
    @Transactional
    public void runHourly() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime from = now.plusHours(24);
        LocalDateTime to   = now.plusHours(25);

        logger.info("Running scheduled reminder check from {} to {}", from, to);

        List<Appointment> upcoming = repo.findByAppointmentDateTimeBetweenAndReminderSentFalse(from, to);

        if (upcoming.isEmpty()) {
            logger.info("No upcoming appointments found for reminder in the next 24-25 hours.");
        } else {
            logger.info("Found {} upcoming appointments for reminder.", upcoming.size());
        }

        for (Appointment appt : upcoming) {
            try {
                logger.info("Processing reminder for appointment ID: {}", appt.getId());
                notificationService.processReminder(appt); 
                appt.setReminderSent(true);                
                repo.save(appt);
                logger.info("Reminder sent and appointment updated successfully for ID: {}", appt.getId());
            } catch (Exception e) {
                logger.error("Failed to process reminder for appointment ID {}: {}", appt.getId(), e.getMessage(), e);
            }
        }
    }
}
