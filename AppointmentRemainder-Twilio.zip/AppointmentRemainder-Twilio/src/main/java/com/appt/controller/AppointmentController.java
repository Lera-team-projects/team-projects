package com.appt.controller;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.appt.entity.Appointment;
import com.appt.repository.AppointmentRepository;
import com.appt.service.NotificationService;
import com.appt.service.PdfGenerationService;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    private static final Logger logger = LoggerFactory.getLogger(AppointmentController.class);
    @Autowired
    private AppointmentRepository repo;
    @Autowired
    private PdfGenerationService pdfService;
    @Autowired
    private NotificationService notify;

    @PostMapping("/add")
    public ResponseEntity<?> create(@RequestBody @Valid Appointment appt, BindingResult result) {
        logger.info("Received request to create appointment: {}", appt);

        if (result.hasErrors()) {
            Map<String, String> errors = result.getFieldErrors()
                                               .stream()
                                               .collect(Collectors.toMap(
                                                   e -> e.getField(),
                                                   e -> e.getDefaultMessage() ));
            logger.warn("Validation errors while creating appointment: {}", errors);
            return ResponseEntity.badRequest().body(errors);
        }

        Appointment saved = repo.save(appt);
        logger.info("Appointment saved successfully with ID: {}", saved.getId());

        try {
            notify.processReminder(saved);
            logger.info("Notification processing initiated for appointment ID: {}", saved.getId());
        } catch (Exception e) {
            logger.error("Error sending notification for appointment ID {}: {}", saved.getId(), e.getMessage(), e);
        }

        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public List<Appointment> list() {
        logger.info("Fetching all appointments");
        List<Appointment> all = repo.findAll();
        logger.info("Found {} appointments", all.size());
        return all;
    }

    @GetMapping("/{id:\\d+}")
    public Appointment get(@PathVariable Long id) {
        logger.info("Fetching appointment with ID: {}", id);
        return repo.findById(id).orElseThrow(() -> {
            logger.error("Appointment not found with ID: {}", id);
            return new RuntimeException("Appointment not found");
        });
    }

    @GetMapping("/{id:\\d+}/download")
    public ResponseEntity<Resource> download(@PathVariable Long id) {
        logger.info("Downloading PDF for appointment ID: {}", id);

        Appointment appt = repo.findById(id).orElseThrow(() -> {
            logger.error("Appointment not found with ID: {}", id);
            return new RuntimeException("Appointment not found");
        });

        ByteArrayResource pdf = pdfService.generateAppointmentSummary(appt);
        logger.info("PDF generated successfully for appointment ID: {}", id);

        String filename = "appointment-" + id + ".pdf";
        return ResponseEntity.ok()
                .contentLength(pdf.contentLength())
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(pdf);
    }
}
