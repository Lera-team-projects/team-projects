package com.appt.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appt.entity.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment,Long>{
List<Appointment> findByAppointmentDateTimeBetweenAndReminderSentFalse(LocalDateTime from,LocalDateTime to);
}
