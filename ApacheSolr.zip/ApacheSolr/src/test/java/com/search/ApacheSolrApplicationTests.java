package com.search;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApacheSolrApplicationTests {

	@Test
	void contextLoads() {
	}

}
