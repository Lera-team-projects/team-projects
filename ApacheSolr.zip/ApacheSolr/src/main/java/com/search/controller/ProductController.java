package com.search.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.search.entity.Product;
import com.search.service.ProductService;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/add")
    public String addProduct(@RequestBody Product product) throws Exception {
        productService.addProduct(product);
        return "Product added successfully!";
    }

    @GetMapping("/search")
    public List<Product> searchProducts(@RequestParam String keyword) throws Exception {
        return productService.searchProducts(keyword);
    }
}


