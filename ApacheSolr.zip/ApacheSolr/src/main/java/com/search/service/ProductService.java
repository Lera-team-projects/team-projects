package com.search.service;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.stereotype.Service;

import com.search.entity.Product;

import java.util.List;

@Service
public class ProductService {

    private final SolrClient solrClient;

    public ProductService(SolrClient solrClient) {
        this.solrClient = solrClient;
    }

    // Search products
    public List<Product> searchProducts(String keyword) throws Exception {
        SolrQuery query = new SolrQuery();
        query.setQuery("name:*" + keyword + "* OR description:*" + keyword + "*");
        QueryResponse response = solrClient.query("products", query);
        return response.getBeans(Product.class);
    }

    // Add or update a product
    public void addProduct(Product product) throws Exception {
        solrClient.addBean("products", product);
        solrClient.commit("products");
    }
}

