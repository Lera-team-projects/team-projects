package com.example.Shopping_kafka.controller;

import com.example.Shopping_kafka.entity.Product;
import com.example.Shopping_kafka.repository.ProductRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController 
{

    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository) 
    {
        this.productRepository = productRepository;
    }


    @GetMapping("/all")
    
    public List<Product> getAllProducts() 
    {
        return productRepository.findAll();
    }

    @GetMapping("/category/{category}")
    
    public List<Product> getProductsByCategory(@PathVariable String category) 
    {
        return productRepository.findByCategory_Name(category);
    }
}