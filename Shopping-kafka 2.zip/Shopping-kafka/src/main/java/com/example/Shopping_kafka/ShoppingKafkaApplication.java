package com.example.Shopping_kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingKafkaApplication.class, args);
	}

}
