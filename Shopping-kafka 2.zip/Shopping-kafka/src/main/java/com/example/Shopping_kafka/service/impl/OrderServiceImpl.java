package com.example.Shopping_kafka.service.impl;

import com.example.Shopping_kafka.dto.OrderItemDto;
import com.example.Shopping_kafka.dto.OrderRequestDto;
import com.example.Shopping_kafka.dto.OrderResponseDto;
import com.example.Shopping_kafka.entity.Order;
import com.example.Shopping_kafka.entity.OrderItem;
import com.example.Shopping_kafka.entity.Product;
import com.example.Shopping_kafka.entity.User;
import com.example.Shopping_kafka.exception.OrderNotFoundException;
import com.example.Shopping_kafka.exception.ProductNotFoundException;
import com.example.Shopping_kafka.exception.UserNotFoundException;
import com.example.Shopping_kafka.kafka.KafkaOrderProducer;
import com.example.Shopping_kafka.repository.OrderRepository;
import com.example.Shopping_kafka.repository.ProductRepository;
import com.example.Shopping_kafka.repository.UserRepository;
import com.example.Shopping_kafka.service.OrderService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final KafkaOrderProducer kafkaOrderProducer;

    public OrderServiceImpl(OrderRepository orderRepository,
                            ProductRepository productRepository,
                            UserRepository userRepository,
                            KafkaOrderProducer kafkaOrderProducer) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.kafkaOrderProducer = kafkaOrderProducer;
    }

    @Override
    public OrderResponseDto placeOrder(OrderRequestDto orderRequestDto) {

        // ✅ Validation
        if (orderRequestDto.getItems() == null || orderRequestDto.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one item");
        }

        // 1️⃣ Fetch user
        User user = userRepository.findById(orderRequestDto.getUserId())
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + orderRequestDto.getUserId()));

        // 2️⃣ Create new Order
        Order order = new Order();
        order.setUser(user);
        order.setOrderDate(LocalDateTime.now());

        List<OrderItem> orderItemList = new ArrayList<>();
        double totalPrice = 0.0;

        // 3️⃣ Add Order Items
        for (OrderItemDto itemDto : orderRequestDto.getItems()) {
            Product product = productRepository.findById(itemDto.getProductId())
                    .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + itemDto.getProductId()));

            double itemPrice = product.getPrice() * itemDto.getQuantity();
            totalPrice += itemPrice;

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProduct(product);
            orderItem.setQuantity(itemDto.getQuantity());
            orderItem.setPrice(itemPrice);

            orderItemList.add(orderItem);
        }

        order.setOrderItems(orderItemList);
        order.setTotalPrice(totalPrice);

        // 4️⃣ Save Order
        Order savedOrder = orderRepository.save(order);

        // 5️⃣ Prepare Response
        List<OrderItemDto> responseItems = new ArrayList<>();
        for (OrderItem orderItem : savedOrder.getOrderItems()) {
            OrderItemDto responseItem = new OrderItemDto();
            responseItem.setProductName(orderItem.getProduct().getName());
            responseItem.setQuantity(orderItem.getQuantity());
            responseItem.setPrice(orderItem.getPrice());
            responseItems.add(responseItem);
        }

        OrderResponseDto response = new OrderResponseDto();
        response.setOrderId(savedOrder.getId());
        response.setUserName(savedOrder.getUser().getuser_name()); // ✅ check getter naming!
        response.setOrderDate(savedOrder.getOrderDate());
        response.setTotalPrice(savedOrder.getTotalPrice());
        response.setItems(responseItems);

        // 6️⃣ Send Order event to Kafka
        kafkaOrderProducer.sendOrder(response);

        return response;
    }

    @Override
    public List<OrderResponseDto> getAllOrders() {
        List<Order> orders = orderRepository.findAll();
        List<OrderResponseDto> responseList = new ArrayList<>();

        for (Order order : orders) {
            List<OrderItemDto> orderItemsDto = new ArrayList<>();
            for (OrderItem orderItem : order.getOrderItems()) {
                OrderItemDto itemDto = new OrderItemDto();
                itemDto.setProductName(orderItem.getProduct().getName());
                itemDto.setQuantity(orderItem.getQuantity());
                itemDto.setPrice(orderItem.getPrice());
                orderItemsDto.add(itemDto);
            }

            OrderResponseDto orderResponse = new OrderResponseDto();
            orderResponse.setOrderId(order.getId());
            orderResponse.setUserName(order.getUser().getuser_name()); // ✅ check getter naming!
            orderResponse.setOrderDate(order.getOrderDate());
            orderResponse.setTotalPrice(order.getTotalPrice());
            orderResponse.setItems(orderItemsDto);

            responseList.add(orderResponse);
        }

        return responseList;
    }

    @Override
    public OrderResponseDto getOrderById(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with ID: " + orderId));

        List<OrderItemDto> orderItemsDto = new ArrayList<>();
        for (OrderItem orderItem : order.getOrderItems()) {
            OrderItemDto itemDto = new OrderItemDto();
            itemDto.setProductName(orderItem.getProduct().getName());
            itemDto.setQuantity(orderItem.getQuantity());
            itemDto.setPrice(orderItem.getPrice());
            orderItemsDto.add(itemDto);
        }

        OrderResponseDto response = new OrderResponseDto();
        response.setOrderId(order.getId());
        response.setUserName(order.getUser().getuser_name()); // ✅ check getter naming!
        response.setOrderDate(order.getOrderDate());
        response.setTotalPrice(order.getTotalPrice());
        response.setItems(orderItemsDto);

        return response;
    }
}
