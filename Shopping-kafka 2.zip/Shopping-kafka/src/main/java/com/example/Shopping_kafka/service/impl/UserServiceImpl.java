package com.example.Shopping_kafka.service.impl;

//import com.example.Shopping_kafka.entity.Product;
import com.example.Shopping_kafka.entity.User;
import com.example.Shopping_kafka.repository.UserRepository;
import com.example.Shopping_kafka.service.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public  class UserServiceImpl implements UserService 
{

    private static final String TOPIC = "shopping-user-topic";

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public User createUser(User user) {
        // Save user to H2 database
        User savedUser = userRepository.save(user);

        String message = "User with ID " + savedUser.getuser_id() + " created successfully.";

        kafkaTemplate.send(TOPIC, message);

        return savedUser;
    }
    @Override
    public List<User> getAllUsers() 
    {
        return userRepository.findAll();
    }
}
