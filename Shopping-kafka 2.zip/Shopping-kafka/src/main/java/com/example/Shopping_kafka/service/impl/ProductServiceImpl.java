package com.example.Shopping_kafka.service.impl;

import com.example.Shopping_kafka.entity.Product;
import com.example.Shopping_kafka.repository.ProductRepository;
import com.example.Shopping_kafka.service.ProductService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService 
{

    private final ProductRepository productRepository;

    public ProductServiceImpl(ProductRepository productRepository) 
    {
        this.productRepository = productRepository;
    }

    @Override
    public List<Product> getAllProducts() 
    {
        return productRepository.findAll();
    }

    @Override
    public List<Product> getProductsByCategory(String category) 
    {
        return productRepository.findByCategory_Name(category);
    }
}
