package com.example.Shopping_kafka.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name= "users")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class User 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id", nullable = false, unique = true)
    private Long user_id;

    public Long getuser_id() {
		return user_id;
	}

	public void setuser_id(Long user_id) {
		this.user_id = user_id;
	}

	public String getuser_name() {
		return user_name;
	}

	public void setuser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getuser_email() {
		return user_email;
	}

	public void setuser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@NotBlank(message = "The user name should not be blank")
    @Column(name = "user_name", nullable = false)
    private String user_name;

    @Email(message = "The email should be valid")
    @NotBlank(message = "The email should not be blank")
    @Column(name = "user_email", nullable = false, unique = true)
    private String user_email;

    @NotBlank(message = "Password is required")
    @Pattern(
        regexp = "^(?=.*[A-Z])(?=.*[0-9].*[0-9])(?=.*[!@#$%^&*()_+\\-={}:;<>?,.]).{6,}$",
        message = "Password must be at least 6 characters, contain 1 uppercase letter, 2 numbers, and 1 special character"
    )
    @Column(nullable = false)
    private String password;
}
