package com.example.Shopping_kafka.service;

import java.util.List;

import com.example.Shopping_kafka.dto.OrderRequestDto;
import com.example.Shopping_kafka.dto.OrderResponseDto;

public interface OrderService {
    OrderResponseDto placeOrder(OrderRequestDto orderRequestDto);
    List<OrderResponseDto> getAllOrders();
    OrderResponseDto getOrderById(Long orderId);
}
