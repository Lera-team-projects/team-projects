package com.example.Shopping_kafka.controller;

//import com.example.Shopping_kafka.entity.Product;
import com.example.Shopping_kafka.entity.User;
//import com.example.Shopping_kafka.repository.UserRepository;
import com.example.Shopping_kafka.service.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/users")
public class UserController 
{

    @Autowired
    private UserService userService;
    

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) 
    {
        User createdUser = userService.createUser(user);

        return ResponseEntity.ok(
            "User registered successfully! Your User ID is: " + createdUser.getuser_id()
        );
    }
    @GetMapping("/all")
    public List<User> getAllUsers() 
    {
        return userService.getAllUsers();   
}
}
