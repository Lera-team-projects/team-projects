package com.example.Shopping_kafka.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "orders") // avoid reserved keyword "order"
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime orderDate;
    private Double totalPrice;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderItem> orderItems;

    // Getters and setters
    public void setUser(User user) { this.user = user; }
    public void setOrderDate(LocalDateTime orderDate) { this.orderDate = orderDate; }
    public void setTotalPrice(Double totalPrice) { this.totalPrice = totalPrice; }
    public void setOrderItems(List<OrderItem> orderItems) { this.orderItems = orderItems; }

    public Long getId() { return id; }
    public User getUser() { return user; }
    public LocalDateTime getOrderDate() { return orderDate; }
    public Double getTotalPrice() { return totalPrice; }
    public List<OrderItem> getOrderItems() { return orderItems; }
	
}
