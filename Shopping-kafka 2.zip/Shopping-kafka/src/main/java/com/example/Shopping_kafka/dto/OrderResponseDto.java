package com.example.Shopping_kafka.dto;

import java.time.LocalDateTime;
import java.util.List;

public class OrderResponseDto {

    private Long orderId;
    private String UserName;
    private LocalDateTime orderDate;
    private double totalPrice;
    private List<OrderItemDto> items;

    // Constructors
    public OrderResponseDto() {}

    public OrderResponseDto(Long orderId, String userName, LocalDateTime orderDate, double totalPrice, List<OrderItemDto> items) {
        this.orderId = orderId;
        this.UserName = userName;
        this.orderDate = orderDate;
        this.totalPrice = totalPrice;
        this.items = items;
    }

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public List<OrderItemDto> getItems() {
		return items;
	}

	public void setItems(List<OrderItemDto> items) {
		this.items = items;
	}
}
