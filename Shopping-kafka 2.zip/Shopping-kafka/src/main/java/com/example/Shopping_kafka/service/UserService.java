package com.example.Shopping_kafka.service;

import java.util.List;

//import com.example.Shopping_kafka.entity.Product;
import com.example.Shopping_kafka.entity.User;

public interface UserService 
{
    User createUser(User user);
    List<User> getAllUsers();

}
