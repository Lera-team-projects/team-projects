package com.example.Shopping_kafka.kafka;

import com.example.Shopping_kafka.dto.OrderResponseDto;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaOrderConsumer {

    @KafkaListener(topics = "shopping-topic", groupId = "order_group")
    public void consumeOrder(OrderResponseDto orderResponse) {
        System.out.println(" Received order from Kafka:");
        System.out.println("Order ID: " + orderResponse.getOrderId());
        System.out.println("Customer: " + orderResponse.getUserName());
        System.out.println("Total Price: " + orderResponse.getTotalPrice());
        System.out.println("Order Items:");
        orderResponse.getItems().forEach(item ->
            System.out.println(item.getProductName() + " x" + item.getQuantity() + " = " + item.getPrice())
        );
        System.out.println("----------------------------");
    }
}
