package com.example.Shopping_kafka.controller;

import com.example.Shopping_kafka.dto.OrderRequestDto;
import com.example.Shopping_kafka.dto.OrderResponseDto;
import com.example.Shopping_kafka.service.OrderService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController 
{
    private final OrderService orderService;

    public OrderController(OrderService orderService) 
    {
        this.orderService = orderService;
    }

    @PostMapping
    public OrderResponseDto placeOrder(@RequestBody OrderRequestDto orderRequest) 
    {
        return orderService.placeOrder(orderRequest);
    }

    @GetMapping
    public List<OrderResponseDto> getAllOrders() 
    {
        return orderService.getAllOrders();
    }

    @GetMapping("/{id}")
    public OrderResponseDto getOrderById(@PathVariable Long id) 
    {
        return orderService.getOrderById(id);
    }
}
