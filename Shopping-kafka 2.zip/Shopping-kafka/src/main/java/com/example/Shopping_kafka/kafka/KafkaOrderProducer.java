package com.example.Shopping_kafka.kafka;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.example.Shopping_kafka.dto.OrderResponseDto;

@Service
public class KafkaOrderProducer 
{
	private final KafkaTemplate<String, OrderResponseDto> kafkaTemplate;
    private static final String TOPIC = "shopping-topic";

    public KafkaOrderProducer(KafkaTemplate<String, OrderResponseDto> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendOrder(OrderResponseDto orderResponse) {
        kafkaTemplate.send(TOPIC, orderResponse);
    }
}



