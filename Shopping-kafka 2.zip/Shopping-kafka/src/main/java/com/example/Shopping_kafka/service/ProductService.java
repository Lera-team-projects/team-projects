package com.example.Shopping_kafka.service;

import com.example.Shopping_kafka.entity.Product;

import java.util.List;

public interface ProductService
{

    List<Product> getAllProducts();

    List<Product> getProductsByCategory(String category);
}
