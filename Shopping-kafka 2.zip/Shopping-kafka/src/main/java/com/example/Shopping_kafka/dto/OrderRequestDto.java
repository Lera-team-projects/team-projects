package com.example.Shopping_kafka.dto;

import java.util.List;

public class OrderRequestDto {

    private Long user_id;
    private List<OrderItemDto> items;

    // Constructors
    public OrderRequestDto() {}

    public OrderRequestDto(Long user_id, List<OrderItemDto> items) {
        this.user_id = user_id;
        this.items = items;
    }

    // Getters and Setters
    public Long getUserId() { return user_id; }
    public void setUserId(Long user_id) { this.user_id = user_id; }

    public List<OrderItemDto> getItems() { return items; }
    public void setItems(List<OrderItemDto> items) { this.items = items; }
}
